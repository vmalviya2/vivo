package com.catalogue.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "seller")
@Entity
public class Seller {

	@Id
	@Column(name = "seller_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer sellerId;

	@Column(name = "seller_name")
	private String sellerName;

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

}
