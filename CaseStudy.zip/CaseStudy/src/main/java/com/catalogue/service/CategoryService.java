package com.catalogue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.entities.Category;
import com.catalogue.repositories.CategoryRepositories;

@Service
public class CategoryService {
	@Autowired
	CategoryRepositories categoryRepositories;

	public Category addBrand(Category category) {
		if (category != null) {
			return categoryRepositories.save(category);
		}

		throw new NullPointerException("Category entity cannot be null");
	}

	public Category getCategoryById(Integer id) {
		return categoryRepositories.findById(id).get();
	}
}
