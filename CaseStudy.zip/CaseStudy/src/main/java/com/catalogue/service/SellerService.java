package com.catalogue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.entities.Seller;
import com.catalogue.repositories.SellerRepositories;

@Service
public class SellerService {

	@Autowired
	SellerRepositories sellerRepositories;

	public Seller addSeller(Seller seller) {
		if (seller != null) {
			return sellerRepositories.save(seller);
		}

		throw new NullPointerException("Seller entity cannot be null");
	}

	public Seller getSellerById(Integer id) {
		return sellerRepositories.findById(id).get();
	}

}
