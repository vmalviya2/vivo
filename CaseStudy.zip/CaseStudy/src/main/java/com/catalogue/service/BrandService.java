package com.catalogue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.entities.Brand;
import com.catalogue.repositories.BrandRepositories;

@Service
public class BrandService {

	@Autowired
	BrandRepositories brandRepositories;

	public Brand addBrand(Brand brand) {
		if (brand != null) {
			return brandRepositories.save(brand);
		}

		throw new NullPointerException("Brand entity cannot be null");
	}

	public Brand getBrandById(Integer id) {
		return brandRepositories.findById(id).get();
	}
	
	public Brand getBrandByName(String brandName) {
		return brandRepositories.findBrandByBrandName(brandName);
	}
}
