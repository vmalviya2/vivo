package com.catalogue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.entities.Supplier;
import com.catalogue.repositories.SupplierRepositories;

@Service
public class SupplierService {

	@Autowired
	SupplierRepositories supplierRepositories;

	public Supplier addSupplier(Supplier supplier) {
		if (supplier != null) {
			return supplierRepositories.save(supplier);
		}

		throw new NullPointerException("Supplier entity cannot be null");
	}

	public Supplier getSupplierById(Integer id) {
		return supplierRepositories.findById(id).get();
	}

}
