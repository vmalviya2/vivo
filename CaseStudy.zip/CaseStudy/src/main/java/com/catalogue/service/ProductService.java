package com.catalogue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.entities.Category;
import com.catalogue.entities.Product;
import com.catalogue.repositories.CategoryRepositories;
import com.catalogue.repositories.ProductRepositories;

@Service
public class ProductService {

	@Autowired
	public ProductRepositories productRepositories;

	public Product addProduct(Product product) {
		if (product != null) {
			return productRepositories.save(product);
		}

		throw new NullPointerException("Product entity cannot be null");
	}

	public Product getProductById(Integer id) {
		if (id != null) {
			return productRepositories.findById(id).get();
		}

		throw new NullPointerException("Id entity cannot be null");
	}

	public List<Product> getAllProductsGroupBY(String groupByProperty) {

		if (groupByProperty.equals("price")) {
			return productRepositories.getProductsGroupByPrice();
		} else if (groupByProperty.equals("price")) {
			return productRepositories.getProductsGroupByPrice();
		} else if (groupByProperty.equals("size")) {
			return productRepositories.getProductsGroupBySize();
		} else if (groupByProperty.equals("color")) {
			return productRepositories.getProductsGroupByColor();
		} else if (groupByProperty.equals("brand")) {
			return productRepositories.getProductsGroupByBrand();
		}
		return null;
	}
	
	public Integer getAvailableNoOfProductsBySeller(String sellerName) {
		return productRepositories.getProductsCountOfSeller(sellerName);
		}

}
