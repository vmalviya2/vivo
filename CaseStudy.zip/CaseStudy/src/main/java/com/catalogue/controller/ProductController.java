package com.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.entities.Brand;
import com.catalogue.entities.Category;
import com.catalogue.entities.Product;
import com.catalogue.entities.Seller;
import com.catalogue.entities.Supplier;
import com.catalogue.service.BrandService;
import com.catalogue.service.CategoryService;
import com.catalogue.service.ProductService;
import com.catalogue.service.SellerService;
import com.catalogue.service.SupplierService;

@RestController
@RequestMapping(path = "/product")
public class ProductController {

	@Autowired
	ProductService productService;

	@Autowired
	BrandService brandService;

	@Autowired
	SellerService sellerService;

	@Autowired
	SupplierService supplierService;

	@Autowired
	CategoryService categoryService;

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {

		Brand brand = brandService.getBrandById(product.getBrandId());
		Category category = categoryService.getCategoryById(product.getCategoryId());
		Seller seller = sellerService.getSellerById(product.getSellerId());
		Supplier supplier = supplierService.getSupplierById(product.getSupplierId());

		product.setBrand(brand);
		product.setCategory(category);
		product.setSeller(seller);
		product.setSupplier(supplier);

		Product productReponse = productService.addProduct(product);
		return new ResponseEntity<Product>(productReponse, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProductsGroupBY(String groupByProperty) {

		List<Product> productReponse = productService.getAllProductsGroupBY(groupByProperty);

		return new ResponseEntity<List<Product>>(productReponse, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<Integer> getAvailableNoOfProductsBySeller(String sellerName) {

		Integer count = productService.getAvailableNoOfProductsBySeller(sellerName);

		return new ResponseEntity<Integer>(count, HttpStatus.OK);
	}	

}
