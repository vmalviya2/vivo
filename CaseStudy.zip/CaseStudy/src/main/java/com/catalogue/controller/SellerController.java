package com.catalogue.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.entities.Seller;
import com.catalogue.service.SellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Seller> addSeller(@RequestBody Seller seller) {
		Seller sellerReponse = sellerService.addSeller(seller);
		return new ResponseEntity<Seller>(sellerReponse, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{id}")
	public ResponseEntity<Seller> getSellerById(@PathVariable(name = "id", value = "id") Integer id) {
		Seller sellerReponse = sellerService.getSellerById(id);
		return new ResponseEntity<Seller>(sellerReponse, HttpStatus.OK);
	}

}
