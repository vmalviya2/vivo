package com.catalogue.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.entities.Brand;
import com.catalogue.service.BrandService;

@RestController
@RequestMapping(path = "/brand")
public class BrandController {

	@Autowired
	BrandService brandService;

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Brand> addBrand(@RequestBody Brand brand) {
		Brand brandReponse = brandService.addBrand(brand);
		return new ResponseEntity<Brand>(brandReponse, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/{id}")
	public ResponseEntity<Brand> getBrandById(@PathVariable(name = "id",value = "id") Integer id) {
		Brand brandReponse = brandService.getBrandById(id);
		return new ResponseEntity<Brand>(brandReponse, HttpStatus.OK);
	}

}
