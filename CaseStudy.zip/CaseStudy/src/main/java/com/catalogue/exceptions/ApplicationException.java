package com.catalogue.exceptions;

public class ApplicationException extends RuntimeException {

}
