package com.catalogue.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.catalogue.entities.Seller;

@Repository
public interface SellerRepositories extends CrudRepository<Seller, Integer> {

}
