package com.catalogue.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.catalogue.entities.Product;

@Repository
public interface ProductRepositories extends CrudRepository<Product, Integer> {

	@Query(name = "Select p FROM Product p GROUP BY p.price")
	List<Product> getProductsGroupByPrice();

	@Query(name = "Select p FROM Product p GROUP BY p.productColor")
	List<Product> getProductsGroupByColor();

	@Query(name = "Select p FROM Product p GROUP BY p.size")
	List<Product> getProductsGroupBySize();

	@Query(name = "Select p FROM Product p GROUP BY p.brand")
	List<Product> getProductsGroupByBrand();

	@Query(name = "Select count(p.productId) FROM Product p where p.seller.sellerName =:sellerName ")
	Integer getProductsCountOfSeller(@Param("sellerName") String sellerName);

}
