package com.catalogue.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.catalogue.entities.Brand;

@Repository
public interface BrandRepositories extends CrudRepository<Brand, Integer>{

	public Brand findBrandByBrandName(String brandName);
	
}
